<?php
defined('ABSPATH') || exit;
final class WSD_Cache {
 private const PREFIX='wsd_v1_'; private const CURRENT_TTL=300; private const HISTORICAL_TTL=31536000;
 public function key(string $month):string{return self::PREFIX.str_replace('-','_',$month);} public function is_current_month(string $month):bool{return $month===wp_date('Y-m');} public function get(string $month){return get_transient($this->key($month));} public function set(string $month,array $aggregate):bool{return set_transient($this->key($month),$aggregate,$this->is_current_month($month)?self::CURRENT_TTL:self::HISTORICAL_TTL);} public function delete(string $month):bool{return delete_transient($this->key($month));}
 public function register_invalidation_hooks():void{foreach(['woocommerce_new_order','woocommerce_update_order','woocommerce_order_status_changed','woocommerce_order_refunded','woocommerce_delete_order','woocommerce_trash_order'] as $hook)add_action($hook,[$this,'invalidate_order']);}
 public function invalidate_order($orderId):void{$order=is_object($orderId)?$orderId:wc_get_order((int)$orderId);if(!$order)return;$created=$order->get_date_created();if($created)$this->delete($created->setTimezone(wp_timezone())->format('Y-m'));}
}
