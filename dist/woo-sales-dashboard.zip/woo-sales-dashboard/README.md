# Woo Sales Dashboard

Lightweight read-only monthly WooCommerce sales dashboard. Install the ZIP via Plugins > Add New > Upload Plugin, activate it, then open Sales Dashboard. Supports HPOS and legacy order storage through WooCommerce APIs. It writes only plugin-owned transient cache data and makes no external requests.
