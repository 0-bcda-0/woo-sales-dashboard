=== Woo Sales Dashboard ===
Requires at least: 6.0
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later

A lightweight, read-only, mobile-first monthly WooCommerce sales dashboard.
